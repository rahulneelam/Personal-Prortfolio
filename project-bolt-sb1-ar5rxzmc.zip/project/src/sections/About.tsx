import React from 'react';
import SectionHeading from '../components/SectionHeading';
import { Download } from 'lucide-react';
import Button from '../components/Button';

const About: React.FC = () => {
  const handleDownloadResume = () => {
    // Create a link element
    const link = document.createElement('a');
    link.href = '/resume.pdf';
    link.download = 'Neelam_Rahul_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading 
          title="About Me" 
          subtitle="Learn more about my background and what drives me" 
          centered
        />
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="relative z-10 rounded-lg overflow-hidden shadow-xl transform transition-transform duration-500 hover:scale-105">
              <img 
                src="https://images.pexels.com/photos/4048655/pexels-photo-4048655.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Profile" 
                className="w-full h-auto"
              />
            </div>
            
            <div className="absolute -bottom-6 -left-6 w-48 h-48 bg-blue-100 dark:bg-blue-900 rounded-lg z-0"></div>
          </div>
          
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              Frontend Developer | Recent B.Tech Graduate
            </h3>
            
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              I am a recent B.Tech graduate with a strong foundation in web development, machine learning, and software engineering. My academic journey has been complemented by practical experience through internships at Wipro and YBI Foundation, where I've worked on real-world projects and enhanced my technical skills.
            </p>
            
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              I'm passionate about creating user-friendly applications and solving complex problems through code. My experience includes working with various technologies like React, Java, Python, and machine learning frameworks. I'm always eager to learn new technologies and contribute to innovative projects.
            </p>
            
            <div className="grid grid-cols-2 gap-4 my-6">
              <div>
                <h4 className="font-bold text-gray-900 dark:text-gray-100">Name:</h4>
                <p className="text-gray-700 dark:text-gray-300">Neelam Rahul</p>
              </div>
              
              <div>
                <h4 className="font-bold text-gray-900 dark:text-gray-100">Email:</h4>
                <p className="text-gray-700 dark:text-gray-300">neelamrahul047@gmail.com</p>
              </div>
              
              <div>
                <h4 className="font-bold text-gray-900 dark:text-gray-100">Location:</h4>
                <p className="text-gray-700 dark:text-gray-300">Hyderabad, India</p>
              </div>
              
              <div>
                <h4 className="font-bold text-gray-900 dark:text-gray-100">Availability:</h4>
                <p className="text-gray-700 dark:text-gray-300">Open to opportunities</p>
              </div>
            </div>
            
            <Button 
              variant="primary" 
              icon={<Download size={18} />}
              onClick={handleDownloadResume}
            >
              Download Resume
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;