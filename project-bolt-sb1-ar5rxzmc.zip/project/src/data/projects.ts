import { Project } from "../types";

export const projects: Project[] = [
  {
    id: "1",
    title: "Travel and Tourism Website",
    description: "A responsive travel website with interactive elements for enhanced user engagement. Implemented cross-browser compatibility and optimized for various screen sizes using modern web technologies.",
    tags: ["HTML", "CSS", "JavaScript", "Responsive Design"],
    imageUrl: "https://images.pexels.com/photos/3278215/pexels-photo-3278215.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    githubUrl: "https://github.com/yourusername/travel-tourism",
    featured: true,
  },
  {
    id: "2",
    title: "Smart Movie Recommender",
    description: "An intelligent movie recommendation system using Python. Features include cosine similarity, TF-IDF vectorization, and sentiment analysis for dynamic recommendations based on user feedback.",
    tags: ["Python", "Machine Learning", "Pandas", "NumPy", "Scikit-learn"],
    imageUrl: "https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    githubUrl: "https://github.com/yourusername/movie-recommender",
    featured: true,
  },
  {
    id: "3",
    title: "Personal Portfolio Website",
    description: "A responsive portfolio website built using React and Tailwind CSS, showcasing my projects, skills, and professional journey.",
    tags: ["React", "Tailwind CSS", "JavaScript", "HTML/CSS"],
    imageUrl: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    githubUrl: "https://github.com/yourusername/portfolio",
    featured: true,
  }
];