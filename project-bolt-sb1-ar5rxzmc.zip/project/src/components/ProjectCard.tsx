import React from 'react';
import { ExternalLink, Github } from 'lucide-react';
import { Project } from '../types';
import Button from './Button';

interface ProjectCardProps {
  project: Project;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  return (
    <div className="group bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 flex flex-col h-full">
      <div className="relative overflow-hidden h-48">
        <img 
          src={project.imageUrl} 
          alt={project.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {project.featured && (
          <div className="absolute top-2 right-2 bg-blue-600 text-white py-1 px-3 text-xs rounded-full">
            Featured
          </div>
        )}
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2">
          {project.title}
        </h3>
        
        <p className="text-gray-600 dark:text-gray-400 mb-4 flex-grow">
          {project.description}
        </p>
        
        <div className="mb-4 flex flex-wrap gap-2">
          {project.tags.map((tag) => (
            <span 
              key={tag} 
              className="bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300 text-xs px-2 py-1 rounded-md"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <div className="flex space-x-3">
          {project.demoUrl && (
            <Button 
              variant="primary" 
              size="sm"
              className="flex-1"
              icon={<ExternalLink size={16} />}
              onClick={() => window.open(project.demoUrl, '_blank')}
            >
              Demo
            </Button>
          )}
          
          {project.githubUrl && (
            <Button 
              variant="outline" 
              size="sm"
              className="flex-1"
              icon={<Github size={16} />}
              onClick={() => window.open(project.githubUrl, '_blank')}
            >
              Code
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;