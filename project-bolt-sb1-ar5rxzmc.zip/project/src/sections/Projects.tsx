import React, { useState, useEffect } from 'react';
import SectionHeading from '../components/SectionHeading';
import ProjectCard from '../components/ProjectCard';
import { projects } from '../data/projects';
import Button from '../components/Button';

const Projects: React.FC = () => {
  // Extract unique tags from all projects
  const allTags = ['All', ...new Set(projects.flatMap(project => project.tags))];
  
  const [activeTag, setActiveTag] = useState('All');
  const [visibleProjects, setVisibleProjects] = useState(projects.slice(0, 3));
  const [showMore, setShowMore] = useState(true);
  
  const filteredProjects = activeTag === 'All'
    ? projects
    : projects.filter(project => project.tags.includes(activeTag));
  
  // Reset visible projects when tag changes
  useEffect(() => {
    setVisibleProjects(filteredProjects.slice(0, 3));
    setShowMore(filteredProjects.length > 3);
  }, [activeTag, filteredProjects.length]);
  
  const handleShowMore = () => {
    const newLength = visibleProjects.length + 3;
    setVisibleProjects(filteredProjects.slice(0, newLength));
    setShowMore(newLength < filteredProjects.length);
  };
  
  return (
    <section id="projects" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          title="My Projects"
          subtitle="A showcase of my latest work and featured projects"
          centered
        />
        
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setActiveTag(tag)}
              className={`px-4 py-2 rounded-md transition-colors duration-200 ${
                activeTag === tag
                  ? 'bg-blue-600 text-white dark:bg-blue-700'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {visibleProjects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
        
        {showMore && (
          <div className="flex justify-center mt-12">
            <Button
              variant="outline"
              onClick={handleShowMore}
            >
              Show More Projects
            </Button>
          </div>
        )}
      </div>
    </section>
  );
};

export default Projects;