import React, { useState } from 'react';
import SectionHeading from '../components/SectionHeading';
import SkillBar from '../components/SkillBar';
import { skills } from '../data/skills';

const Skills: React.FC = () => {
  const categories = ['all', 'frontend', 'backend', 'design', 'tools'] as const;
  const [activeCategory, setActiveCategory] = useState<typeof categories[number]>('all');
  
  const filteredSkills = activeCategory === 'all' 
    ? skills 
    : skills.filter(skill => skill.category === activeCategory);
  
  const categoryLabels = {
    all: 'All Skills',
    frontend: 'Frontend',
    backend: 'Backend',
    design: 'Design',
    tools: 'Tools & DevOps'
  };
  
  return (
    <section id="skills" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading 
          title="Skills & Expertise" 
          subtitle="My technical skills and proficiency levels" 
          centered
        />
        
        <div className="flex justify-center mb-12">
          <div className="inline-flex flex-wrap justify-center gap-2 p-1 bg-gray-200 dark:bg-gray-700 rounded-lg">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-md transition-colors duration-200 ${
                  activeCategory === category
                    ? 'bg-white dark:bg-gray-600 text-blue-600 dark:text-blue-400 shadow-sm'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                {categoryLabels[category]}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-x-12 gap-y-8 max-w-4xl mx-auto">
          {filteredSkills.map((skill) => (
            <SkillBar key={skill.name} skill={skill} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;