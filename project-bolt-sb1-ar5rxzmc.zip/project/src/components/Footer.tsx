import React from 'react';
import { XIcon as Icon } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { socialLinks } from '../data/socialLinks';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  // Dynamic icon rendering from Lucide
  const renderIcon = (iconName: string) => {
    const LucideIcon = (LucideIcons as Record<string, Icon>)[iconName];
    return LucideIcon ? <LucideIcon size={20} /> : null;
  };

  return (
    <footer className="bg-gray-100 dark:bg-gray-900 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:justify-between items-center">
          <div className="mb-6 md:mb-0">
            <a href="#" className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              Portfolio
            </a>
            <p className="mt-2 text-gray-600 dark:text-gray-400">
              Building digital experiences with passion and precision.
            </p>
          </div>
          
          <div className="flex space-x-4">
            {socialLinks.map((link) => (
              <a
                key={link.platform}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 transition-colors duration-200"
                aria-label={link.platform}
              >
                {renderIcon(link.icon)}
              </a>
            ))}
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-800 text-center">
          <p className="text-gray-600 dark:text-gray-400">
            © {currentYear} Neelam Rahul. All rights reserved.
          </p>
          <div className="mt-2 flex justify-center space-x-6">
            <a href="#" className="text-gray-600 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 transition-colors duration-200">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-600 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 transition-colors duration-200">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;