import { Experience } from "../types";

export const experiences: Experience[] = [
  {
    id: "1",
    role: "B.Tech in Computer Science",
    company: "Bharath Institute of Higher Education and Research",
    location: "Chennai, India",
    duration: "2021 - 2025",
    description: [
      "Completed B.Tech with a GPA of 8.0/10.0",
      "Developed strong foundation in programming languages, data structures, and algorithms",
      "Participated in various technical workshops and coding competitions",
      "Worked on multiple academic projects involving web development and machine learning"
    ],
    skills: ["Java", "Python", "Data Structures", "Algorithms", "Problem Solving"]
  },
  {
    id: "2",
    role: "Intermediate Education",
    company: "SR Prime Junior College",
    location: "India",
    duration: "2019 - 2021",
    description: [
      "Achieved excellent academic performance with a score of 942/1000",
      "Participated in various academic competitions",
      "Developed strong foundation in science and mathematics",
      "Active participation in extracurricular activities"
    ],
    skills: ["Mathematics", "Science", "Chemistry"]
  },
  {
    id: "3",
    role: "Secondary Education (X)",
    company: "SPR School of Excellence",
    location: "India",
    duration: "2018 - 2019",
    description: [
      "Completed secondary education with an outstanding GPA of 9.7/10",
      "Demonstrated exceptional academic performance",
      "Participated in school competitions and events",
      "Developed strong analytical and problem-solving skills"
    ],
    skills: ["Academic Excellence", "Leadership", "Problem Solving"]
  },
  {
    id: "4",
    role: "Data Science and Machine Learning Intern",
    company: "YBI Foundation",
    location: "Remote",
    duration: "2023",
    description: [
      "Gained practical experience in data science and machine learning concepts",
      "Worked on real-world datasets and implemented various ML algorithms",
      "Developed proficiency in data preprocessing and analysis",
      "Collaborated with other interns on group projects"
    ],
    skills: ["Python", "Machine Learning", "Data Analysis", "Scikit-learn"]
  },
  {
    id: "5",
    role: "Java Full Stack Development",
    company: "Wipro",
    location: "Remote",
    duration: "2024",
    description: [
      "Completed comprehensive training in Java full-stack development",
      "Learned enterprise-level application development practices",
      "Gained experience with Spring Boot and related technologies",
      "Worked on practical projects to apply learned concepts"
    ],
    skills: ["Java", "Spring Boot", "Web Development", "Full Stack"]
  },
  {
    id: "6",
    role: "Android Development Virtual Internship",
    company: "Remote",
    location: "Virtual",
    duration: "2024",
    description: [
      "Participated in a virtual internship focused on Android development",
      "Learned mobile app development best practices",
      "Worked on practical Android projects",
      "Gained experience with Android Studio and related tools"
    ],
    skills: ["Android", "Java", "Mobile Development", "UI Design"]
  }
];