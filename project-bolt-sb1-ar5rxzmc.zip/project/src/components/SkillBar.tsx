import React from 'react';
import { Skill } from '../types';

interface SkillBarProps {
  skill: Skill;
}

const SkillBar: React.FC<SkillBarProps> = ({ skill }) => {
  // Convert level (1-5) to percentage
  const percentage = (skill.level / 5) * 100;
  
  // Determine color based on category
  const colorClasses = {
    frontend: 'bg-blue-500 dark:bg-blue-600',
    backend: 'bg-purple-500 dark:bg-purple-600',
    design: 'bg-pink-500 dark:bg-pink-600',
    tools: 'bg-teal-500 dark:bg-teal-600',
  };
  
  const bgColorClass = colorClasses[skill.category];
  
  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-1">
        <span className="text-gray-800 dark:text-gray-200 font-medium">
          {skill.name}
        </span>
        <span className="text-sm text-gray-600 dark:text-gray-400">
          {skill.level}/5
        </span>
      </div>
      
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 overflow-hidden">
        <div 
          className={`h-2.5 rounded-full transition-all duration-1000 ${bgColorClass}`}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default SkillBar;