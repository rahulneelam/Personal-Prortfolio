import { Skill } from "../types";

export const skills: Skill[] = [
  // Programming Languages
  {
    name: "Java",
    level: 4,
    category: "backend",
  },
  {
    name: "Python",
    level: 5,
    category: "backend",
  },
  {
    name: "JavaScript",
    level: 4,
    category: "frontend",
  },
  
  // Frontend Development
  {
    name: "React",
    level: 4,
    category: "frontend",
  },
  {
    name: "Next.js",
    level: 4,
    category: "frontend",
  },
  {
    name: "HTML/CSS",
    level: 5,
    category: "frontend",
  },
  
  // Data Science & ML
  {
    name: "Machine Learning",
    level: 4,
    category: "tools",
  },
  {
    name: "Data Science",
    level: 4,
    category: "tools",
  },
  {
    name: "MySQL",
    level: 5,
    category: "backend",
  },
  
  // Problem Solving
  {
    name: "Data Structures",
    level: 4,
    category: "tools",
  },
  {
    name: "Algorithms",
    level: 3,
    category: "tools",
  },
  {
    name: "Problem Solving",
    level: 5,
    category: "tools",
  },
  
  // Additional Skills
  {
    name: "Git",
    level: 4,
    category: "tools",
  },
  {
    name: "Debugging",
    level: 3,
    category: "tools",
  },
];