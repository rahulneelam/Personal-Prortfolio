import { SocialLink } from "../types";

export const socialLinks: SocialLink[] = [
  {
    platform: "GitHub",
    url: "https://github.com/rahulneelam",
    icon: "Github",
  },
  {
    platform: "LinkedIn",
    url: "https://www.linkedin.com/in/neelam-rahul-0a042a257/",
    icon: "Linkedin",
  },
  {
    platform: "Twitter",
    url: "https://twitter.com/yourhandle",
    icon: "Twitter",
  },
  {
    platform: "Email",
    url: "mailto:neelamrahul047@gmail.com",
    icon: "Mail",
  },
];