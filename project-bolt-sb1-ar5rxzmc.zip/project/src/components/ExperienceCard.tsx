import React from 'react';
import { Experience } from '../types';
import { Briefcase } from 'lucide-react';

interface ExperienceCardProps {
  experience: Experience;
  isLast?: boolean;
}

const ExperienceCard: React.FC<ExperienceCardProps> = ({ experience, isLast = false }) => {
  return (
    <div className="relative pl-8 pb-8">
      {/* Timeline line */}
      {!isLast && (
        <div className="absolute left-3 top-0 h-full w-0.5 bg-blue-200 dark:bg-blue-800 transform translate-x-px"></div>
      )}
      
      {/* Timeline dot */}
      <div className="absolute left-0 top-1 w-6 h-6 bg-blue-500 dark:bg-blue-600 rounded-full flex items-center justify-center">
        <Briefcase size={14} className="text-white" />
      </div>
      
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            {experience.role}
          </h3>
          <span className="text-sm font-medium text-gray-500 dark:text-gray-400 mt-1 sm:mt-0">
            {experience.duration}
          </span>
        </div>
        
        <p className="text-gray-700 dark:text-gray-300 font-medium mb-2">
          {experience.company} • {experience.location}
        </p>
        
        <ul className="list-disc list-inside space-y-2 text-gray-600 dark:text-gray-400 mb-4">
          {experience.description.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
        
        <div className="flex flex-wrap gap-2 mt-2">
          {experience.skills.map((skill) => (
            <span 
              key={skill} 
              className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs px-2 py-1 rounded-md"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExperienceCard;